/* eslint-disable */
// @ts-ignore
import ZXDialogAlert from './ZXDialogAlert.vue';
var $vm;
var plugin = {
    install: function (vue) {
        var Toast = vue.extend(ZXDialogAlert);
        if (!$vm) {
            $vm = new Toast({
                el: document.createElement('div')
            });
            document.body.appendChild($vm.$el);
        }
        var $ZXDialogAlert = {
            show: function (opts) {
                $vm.show = false;
                opts = Object.assign({}, opts);
                opts.props = opts.props || {};
                opts._event = opts._event || {};
                opts.content = opts.content || null;
                opts.components = opts.components || null;
                var FilterField = {
                    onShow: true,
                    onHide: true,
                    onClose: true,
                    opened: true,
                    closed: true,
                    _event: true,
                };
                for (var i in opts) {
                    if (FilterField[i]) {
                        $vm[i] = opts[i];
                    }
                    else {
                        $vm.$props[i] = opts[i];
                    }
                }
                $vm.show = true;
            },
            hide: function () {
                $vm.show = false;
            }
        };
        if (!vue.$ZAlert) {
            vue.$ZAlert = $ZXDialogAlert;
        }
        vue.mixin({
            created: function () {
                this.$ZAlert = vue.$ZAlert;
            }
        });
    }
};
export default plugin;
export var install = plugin.install;
