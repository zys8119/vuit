<script>
export default {
    name: "renderHtml",
    props:['renderHtml'],
    render() {
        return this.renderHtml()
    }
}
</script>

<style scoped lang="less">
.renderHtml{
}
</style>