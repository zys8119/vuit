<template>
    <div id="tabsNav">
        <div class="nav-content">
            <div class="content">
                <ul id="navContentUl">
                    <li v-for="(item, key) in navList" :key="key" :class="item.path === $route.path ? 'active' : ''">
                        <div class="con">
                            <span class="name" v-text="item.name" @click="clickTab(item)"></span>
                            <span class="el-icon-close" @click="removeTab(key, item.path === $route.path)"></span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="nav-arrow">
            <el-dropdown>
                <span class="el-icon-s-operation"></span>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item @click.stop.native="refreshCurrent" class="t-a-c">刷新当前</el-dropdown-item>
                    <el-dropdown-item class="t-a-c">全部关闭</el-dropdown-item>
                    <el-dropdown-item class="t-a-c">除此之外关闭全部</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
    </div>
</template>

<script>
export default {
    name: "tabsNav",
    data() {
        return {
            navList: ''
        }
    },
    mounted() {
        this.navList = this.$store.state.menu.navMenuList
        this.$nextTick(function () {
            // 超出横向滚动
            let element = document.getElementById('navContentUl')
            document.addEventListener('DOMMouseScroll',handler,false)
            document.addEventListener('mousewheel',handler,false)
            function handler(event){
                let detail = event.wheelDelta || event.detail;
                let moveForwardStep = 1;
                let moveBackStep = -1;
                let step = 0;
                if(detail > 0) step = moveForwardStep * 100
                else step = moveBackStep * 100
                element.scrollLeft += step;
            }
        })
    },
    methods: {
        removeTab(k, type) {
            let self = this
            let len = this.navList.length
            if (len < 2) return
            if (type) {
                let lastObj = self.navList[len - 2]
                if (lastObj) self.$router.push(lastObj.path)
                else self.$router.push('/')
            }
            this.navList.splice(k, 1)
        },
        clickTab(row){
            this.$router.push(row.path)
        },
        // 刷新当前
        refreshCurrent() {
            let currentComponent = this.$route.matched[this.$route.matched.length - 1].instances.default
            if (currentComponent && typeof currentComponent.init === "function") currentComponent.init()
        }
    }
}
</script>

<style scoped lang="less">
    .tabsNav {
        height: 50px;
        border: 1px solid red;
    }
</style>
