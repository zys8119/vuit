<!--报道管理-->
<template>
    <div id="RegisterManage">
    </div>
</template>

<script>
export default {
    name: "RegisterManage",
    data() {
        return {}
    },
    mounted() {
    },
    methods:{
    }
}
</script>

<style scoped>

</style>