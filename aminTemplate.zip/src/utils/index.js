import QRCode from 'qrcodejs2';
export default {
    /**
     * 验证手机号
     * @param num
     */
    checkPhoneNumber: function (mobile) {
        var _mobile = mobile.replace(/(^\s*)|(\s*$)/g, "");
        var reg = /^(1[1-9][0-9])\d{8}$/i;
        if (!reg.test(_mobile)) {
            window._this.$message.error('手机号格式不正确');
            return false;
        }
        return true;
    },
    /**
     * 扫码登录 websocket通讯
     * @param token
     * @param code
     */
    qrcodeLoginWS: function (token, code) {
        var url = window.common.postUrl.replace('http://', '');
        var ws;
        // 本地请求 域名http请求
        if (window.location.hostname === 'localhost' || window.location.protocol === 'http:') {
            ws = new WebSocket('ws://' + url + '/app_auth/?' + token);
        }
        else if (window.location.protocol === 'https:') {
            ws = new WebSocket('wss://' + url + '/app_auth/?' + token);
        }
        ws.onopen = function () {
            // 制作二维码
            document.getElementById('qrcode').innerHTML = '';
            new QRCode('qrcode', {
                width: 280,
                height: 280,
                text: code
            });
        };
        ws.onmessage = function (evt) {
            var d = JSON.parse(evt.data);
            if (d.cmd === 'user_confirm') {
                sessionStorage.userInfo = JSON.stringify(d.user_info);
                window.location.hash = '/';
            }
            ws.close();
        };
    }
};
