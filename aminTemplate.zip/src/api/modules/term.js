export default {
    history: function () {
        return window.common.Axios({
            url: "/v1/pc/common/term/history/",
            dom: ".RepresentativeStatistics"
        });
    }
};
