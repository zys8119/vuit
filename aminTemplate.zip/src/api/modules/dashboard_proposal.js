export default {
    jianyi: function (data) {
        return window.common.Axios({
            url: "/v1/pc/dashboard/proposal/jianyi/",
            data: data,
            dom: ".SuggestedMotionStatistics"
        });
    },
    yian: function (data) {
        return window.common.Axios({
            url: "/v1/pc/dashboard/proposal/yian/",
            data: data,
            dom: ".SuggestedMotionStatistics"
        });
    },
    zonglan: function (data) {
        return window.common.Axios({
            url: "/v1/pc/dashboard/proposal/zonglan/",
            data: data,
            dom: ".SuggestedMotionStatistics"
        });
    },
    termcount: function () {
        return window.common.Axios({
            url: "/v1/pc/dashboard/proposal/termcount/",
        });
    }
};
