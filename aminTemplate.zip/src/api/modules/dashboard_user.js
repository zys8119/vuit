export default {
    rddb: function (data) {
        return window.common.Axios({
            url: "/v1/pc/dashboard/user/rddb/",
            data: data,
            dom: ".RepresentativeStatistics"
        });
    }
};
