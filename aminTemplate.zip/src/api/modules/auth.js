export default {
    login: function (data) {
        return window.common.Axios({
            url: '/v1/auth/login/',
            data: data,
            method: 'post',
            dom: '.main-content'
        });
    },
    getCode: function (data, dom) {
        if (dom === void 0) { dom = '.main-content'; }
        return window.common.Axios({
            url: '/v1/auth/getCode/',
            data: data,
            method: 'post',
            dom: dom
        });
    },
    resetPwd: function (data) {
        return window.common.Axios({
            url: '/v1/auth/resetPwd/',
            data: data,
            method: 'post',
            dom: '.forget-content'
        });
    },
    generateLoginCode: function (data) {
        return window.common.Axios({
            url: '/v1/auth/generateLoginCode/',
            data: data,
            method: 'get',
            dom: '.scan-login-content'
        });
    }
};
