export default {
    getLoginInfo: function () {
        return window.common.Axios({
            url: '/v1/pc/dashboard/statistics/getLoginInfo/',
            method: 'get',
            dom: '.static-content'
        });
    },
    getActivityInfo: function (data) {
        return window.common.Axios({
            url: "/v1/pc/dashboard/statistics/getActivityInfo/",
            dom: '.DutyActivityStatistics',
            data: data,
        });
    },
    getConferenceInfo: function (data) {
        return window.common.Axios({
            url: "/v1/pc/dashboard/statistics/getConferenceInfo/",
            data: data,
            dom: ".MeetingStatistics"
        });
    }
};
