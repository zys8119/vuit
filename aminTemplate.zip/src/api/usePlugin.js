import Api from "./index";
import $utils from "../utils";
import filters from "../filters";
var usePlugin = {
    install: function (vue) {
        vue.prototype.$utils = $utils;
        vue.prototype.api = Api;
        vue.mixin({
            filters: filters
        });
    }
};
export default usePlugin;
