export default {
    path: '/home',
    name: '首页',
    component: () => import('../../components/views/Home/Home.vue')
}
