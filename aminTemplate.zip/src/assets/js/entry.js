// 引入全局页面 js
import './common.js'
