/**
 * 全局过滤器
 */
export default {}